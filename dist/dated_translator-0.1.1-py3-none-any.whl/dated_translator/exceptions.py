class SetupError(Exception):
    pass


class MissingColumn(Exception):
    pass
